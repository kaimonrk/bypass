files/AreaData.dat = store old device hardware resolution
delete it if using gfx
